<?php

	// Run as cronjob every hour. This updates definitions of champions.
	// Uploads them to database for later use.

	require_once(__DIR__."/../loader.php");

	require_once("$_sys/common.php");
	require_once("$_sys/res/apikey.php");
	require_once("$_sys/res/dbconn.php");
	require_once("$_sys/func/setCacheData.php");
	require_once("$_sys/func/getRemoteData.php");


	function UpdateChampions() {
		$response = getRemoteData("https://global.api.pvp.net/api/lol/static-data/euw/v1.2/champion?champData=all&api_key=".getAPIKey());
		if (!$response) reportError("Connection with API failed!", __FILE__, __LINE__);

		$version = $response["version"];
		$query = "INSERT INTO `champions` (id, name, title, icon, image) VALUES ";

		foreach($response["data"] as $data) {
			$key = $data["key"];

			$littleIcon = "http://ddragon.leagueoflegends.com/cdn/$version/img/champion/{$key}.png";
			$splashArt  = "http://ddragon.leagueoflegends.com/cdn/img/champion/splash/{$key}_0.jpg";

			if (!is_int($data["id"])) reportError("ID should be int, but isn't!", __FILE__, __LINE__);
			elseif (preg_match("[a-zA-Z'\- ]", $data["name"])) reportError("Name should be matching regex, but doesn't!", __FILE__, __LINE__);
			elseif (preg_match("[a-zA-Z '-]", $data["title"])) reportError("Title should be matching regex, but doesn't!", __FILE__, __LINE__);
			elseif (!filter_var($littleIcon, FILTER_VALIDATE_URL) || preg_match("[a-zA-Z/.:0-9_]", $littleIcon)) reportError("Little icon URL is invalid or potentially dangerous!", __FILE__, __LINE__);
			elseif (!filter_var($bigIcon, FILTER_VALIDATE_URL) || preg_match("[a-zA-Z/.:0-9_]", $splashArt)) reportError("Splash art URL is invalid or potentially dangerous!", __FILE__, __LINE__);

			$query .= "(".$data["id"].", \"".$data["name"]."\", \"".$data["title"]."\", \"".$littleIcon."\", \"".$splashArt."\"), ";
		}

		$query = substr($query, 0, -2);

		if (!setCacheData("TRUNCATE TABLE champions;")) reportError("Cannot TRUNCATE required table!", __FILE__, __LINE__);
		if (!setCacheData($query)) reportError("Cannot upload SQL data!", __FILE__, __LINE__);
		return true;
	}

	if (!UpdateChampions()) {
		die "Champion update failed. False returned";
	}

?>
