<?php

	error_reporting(0);		// hide other errors that don't affect security or working of the script
	$showError = false;		// show errors that matter, if true, show errors otherwise hide them


	// It reports errors, nothing else, if something is wrong, and you enabled
	// debugging, it will show errors and die(), if you disabled debugging it
	// just returns false.
	function reportError($text, $file, $line) {
		global $showError;

		if ($showError) {
			die("
				<br />
				<hr />
				$text<br />
				<b>$file</b> on line <b>$line</b><br />
				<hr />
				<br />
			");
			return false;
		}
		else {
			return false;
		}
	}


	// Redirects and prevents future execution of script (which apparently goes on).
	function redirect($url) {
		if (empty($url)) reportError("Provided URL is empty!", __FILE__, __LINE__);
		header("Location: $url");
		exit;
	}

?>
