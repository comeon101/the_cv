<?php

	// Allows for easy configuation of include files.
	// Instead of worrying on "I have to change URL
	// in every single file now". You can just change
	// it here.

	$_sys = $_SERVER["DOCUMENT_ROOT"] . "/riot/__sys";

?>
