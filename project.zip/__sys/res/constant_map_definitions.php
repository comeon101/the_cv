<?php

	// Unfortunately these need to be updated manually.
	// Definitions of maps, that are inaccessible
	// through API.

	$maps = array(
		1 => "Old Summoner's Rift",
		2 => "Old Summoner's Rift",
		3 => "The Proving Grounds",
		4 => "Old Twisted Treeline",
		8 => "The Crystal Scar",
		10 => "Twisted Treeline",
		11 => "Summoner's Rift",
		12 => "Howling Abyss",
		14 => "Butcher's Bridge"
	);

?>
