<?php

	// Simple MySQL connection.
	// Connected? Great.
	// Failed? Fatal error.

	require_once(__DIR__."/../loader.php");
	require_once("$_sys/common.php");

	$dbconn = new mysqli("127.0.0.1", "root", "", "api");
	if (!$dbconn) reportError("Connecting with MySQLi database has failed!", __FILE__, __LINE__);

?>
