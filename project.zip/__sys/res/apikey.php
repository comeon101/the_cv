<?php

	// Because API requests are so scarce you can't create reliable
	// application with single one key. I just got bunch of them xD


	$apikey[0] = "RGAPI-14ec5636-f200-4651-95df-812f98bbc673";
	$apikey[1] = "RGAPI-b5c404cc-2d56-4629-982b-fb00a332b0a0";
	$apikey[2] = "RGAPI-f4aedf40-01d3-4957-8e78-8cefe674c98b";
	$apikey[3] = "RGAPI-1b387daf-9228-4546-b9f4-6234b0411cba";
	$apikey[4] = "RGAPI-c356ddc5-dd15-4fc8-b1e2-ce0116bb81fd";
	$apikey[5] = "RGAPI-e47bc86c-923e-4885-93a5-a9e61b75d739";
	$apikey[6] = "RGAPI-6bdf0c26-5d64-40d0-b686-972589a76d48";
	$apikey[7] = "RGAPI-53bbe3c5-688f-48eb-8983-042a05d7df3b";
	$apikey[8] = "RGAPI-6859dc49-c7fd-491e-a0d3-f38c0e2bec8f";
	$apikey[9] = "RGAPI-b2bb3ab9-0614-41bf-b5aa-fde94823a4df";

	function getAPIKey() {
		global $apikey;

		return $apikey[rand(0, 9)];
	}

?>
