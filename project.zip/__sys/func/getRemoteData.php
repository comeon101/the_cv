<?php

	// Gets JSON response from RESTful API and returns PHP array.

	function getRemoteData($req) {
		if (!filter_var($req, FILTER_VALIDATE_URL)) reportError("Provided URL isn't valid!", __FILE__, __LINE__);

		usleep(200000);
		// For someone reason requesting data too fast,
		// temporarily blocks you from API, even if you're
		// in your quota.

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $req);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$resContent = curl_exec($ch);
		$resHeader = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		if ($resHeader != 200) {
			reportError("Remote cache returned non-200 response code!<br /><i>$req</i>", __FILE__, __LINE__);
		}
		$resContent = json_decode($resContent, true);
		curl_close($ch);

		if (!$resContent) return false;
		else return $resContent;
	}

?>
