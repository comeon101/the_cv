<?php

	// Read files. Even though I never used it, I've written it
	// barebones just for future use, which never came.

	function getDiskData($file) {
		$dataFromFile = file_get_contents($file);
		if (!$dataFromFile) reportError("Failed to open file!", __FILE__, __LINE__);

		$dataFromFile = json_decode($dataFromFile, true);
		if (!$dataFromFile) reportError("JSON decode failed!", __FILE__, __LINE__);

		return $dataFromFile;
	}

?>
