<?php

	// Regex is requirement of API.
	// If name is not allowed, false, if it's correct, true.

	function isNameValid($name) {
		$regex_validName = "/^[0-9\p{L} _\.]+$/";

		return (preg_match($regex_validName, $name) === true);
	}

?>
