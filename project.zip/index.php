<?php require_once(__DIR__."/__sys/loader.php"); ?>
<html>
	<head>
		<?php header("Page: index.php"); ?>
		<?php require_once("$_sys/head.php"); ?>
		<script src="js/index.js"></script>
		<link rel="stylesheet" href="css/general.css" media="all" />
		<link rel="stylesheet" href="css/index.css"   media="all" />
	</head>
	<body>
		<div class="wrapper">
			<form id="submitForm" action="player.php" method="GET">
				<input class="searchbar" id="index" name="name" type="text" placeholder="Input username to find out about him or her" list="predefined" autocomplete="off" />
				<input class="submitButton" type="submit" />
			</form>
			<datalist id="predefined">
				<option value="Taikki">
				<option value="Sephiroth">
				<option value="Eric Clapton">
				<option value="Eddie Van Halen">
				<option value="Rob Gravelle">
			</datalist>
		</div>
		<noscript>
			<div class="error<?php echo ((isset($_GET["err"]) && $_GET["err"] == true) ? "" : " hidden"); ?>">
				<div class="header"><b>User doesn't exist</b></div>
				<div class="content">
					Riot Games didn't send any data. It's possible that user doesn't exist.<br />
					<br />
					<b>Warning!</b> Their database is pretty buggy. If you're sure player exists, try reentering again.
				</div>
			</div>
		</noscript>
	</body>
</html>
