$(document).ready(function () {
	var obj_searchbar    = $("input.searchbar#index"),
		obj_processBlock = $(".process"),
		obj_errorBlock   = $(".errorJS"),
		obj_searchForm   = $("#submitForm"),
		obj_mask         = $(".mask"),
		searchName, responseHeader;


	function getPlayer(searchName) {
		$.ajax({
			url: "player.php",
			type: "GET",
			data: {name: searchName},
			complete: function (XMLHttpRequest) {
				responseHeader = XMLHttpRequest.getResponseHeader("Page");

				if (responseHeader == "index.php") {
					$(obj_mask).addClass("hidden");
					$(obj_errorBlock).removeClass("hidden").delay(5000).queue(function() {
						$(this).addClass("hidden").dequeue();
					});
					$(obj_processBlock).addClass("hidden");
					$(obj_searchbar).removeClass("hidden");
				}
				else if (responseHeader == "player.php") {
					window.location = "player.php?name="+searchName;
				}
				else { console.warn("Oh, haha, really funny"); return false; }
			}
		});
	}


	// JavaScript hijack input form, let JavaScript process.
	$("#submitForm").submit(function (e) { e.preventDefault(); });
	$("input.searchbar").keyup(function (key) {
		if (key.keyCode == 13) {

			// Initiate loading screen: show "Loading..." and hide searchbar
			$(obj_processBlock).removeClass("hidden");
			$(obj_errorBlock).addClass("hidden");
			$(obj_searchbar).addClass("hidden");

			searchName = $(obj_searchbar).val();
			getPlayer(searchName);
		}
	});
});
