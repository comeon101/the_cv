$(document).ready(function () {
	$(".timeSlot").timeago();

    $("\
        <form id=\"submitForm\" action=\"player.php\" method=\"GET\">\
            <input class=\"searchbar hidden\" name=\"name\" id=\"player\" type=\"text\" placeholder=\""+getPlayerName+"\" spellcheck=\"false\" autocomplete=\"off\" />\
            <input class=\"submitButton\" type=\"submit\" />\
        </form>\
		<div class=\"mask\">&nbsp;</div>\
    ").insertBefore("body .wrapper > .header");


    var obj_searchbar    = $("input.searchbar#player"),
        obj_backBtn      = $("a.backBtn"),
        obj_processBlock = $(".process"),
        obj_errorBlock   = $(".errorJS"),
        obj_searchForm   = $("#submitForm"),
		obj_mask         = $(".mask"),
        obj_wrapper      = $(".wrapper");


    function getPlayer(searchName) {
    	$.ajax({
    		url: "player.php",
    		type: "GET",
    		data: {name: searchName},
    		complete: function (XMLHttpRequest) {
    			responseHeader = XMLHttpRequest.getResponseHeader("Page");

				if (responseHeader == "index.php") {
					$(obj_errorBlock).removeClass("hidden").delay(4000).queue(function() {
						$(this).addClass("error").dequeue();
					});
                    $(obj_wrapper).removeClass("blur");
					$(obj_mask).removeClass("enable");
					$(obj_processBlock).addClass("hidden");
					$(obj_searchbar).removeClass("hidden");
			    }
        		else if (responseHeader == "player.php") {
        			window.location = "player.php?name="+searchName;
        		}
        		else { console.warn("Oh, haha, really funny"); return false; }
        	}
        });
    }


    $(obj_backBtn).click(function (e) {
        $(obj_searchbar).removeClass("hidden").focus();
        e.preventDefault();
    });

    $(obj_searchForm).submit(function (e) { e.preventDefault(); });

    $(obj_searchbar).focusout(function () {
        $(this).addClass("hidden");
    });

	$(obj_searchbar).focus(function () {
		$(obj_errorBlock).addClass("hidden");
	});


    $(obj_searchbar).keyup(function (key) {
		if (key.keyCode == 13) {

			// Initiate loading screen: show "Loading..." and hide searchbar
			$(obj_processBlock).removeClass("hidden");
			$(obj_mask).addClass("enable");

            $(obj_searchbar).addClass("hidden").delay(200).queue(function() {
                $(obj_wrapper).addClass("blur").dequeue();
            });

			searchName = $(obj_searchbar).val();
			getPlayer(searchName);
		}
    });
});
