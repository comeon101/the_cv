$(document).ready(function () {
	$("\
		<div class=\"process hidden\">\
			<div class=\"circleWrap\">\
				<div class=\"circle\">\
					&nbsp;\
				</div>\
			</div>\
			<span class=\"loadText\">Loading...</span>\
			<span class=\"subText\">(may take a while)</span>\
		</div>\
		\
		<div class=\"errorJS hidden\">\
			<div class=\"header\"><b>User doesn't exist</b></div>\
			<div class=\"content\">\
				Riot Games didn't send any data. It's possible that user doesn't exist.<br />\
				<br />\
				<b>Warning!</b> Their database is pretty buggy. If you're sure player exists, try reentering again.\
			</div>\
		</div>\
	").insertAfter("body > .wrapper");
});
